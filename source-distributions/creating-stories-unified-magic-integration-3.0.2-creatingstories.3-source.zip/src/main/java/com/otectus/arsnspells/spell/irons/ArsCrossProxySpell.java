package com.otectus.arsnspells.spell.irons;

import com.otectus.arsnspells.spell.CrossCastingHandler;
import com.otectus.arsnspells.spell.CrossModSpell;
import com.otectus.arsnspells.spell.CrossModSpellComponents;
import com.otectus.arsnspells.config.AnsConfig;
import io.redspace.ironsspellbooks.api.config.DefaultConfig;
import io.redspace.ironsspellbooks.api.magic.MagicData;
import io.redspace.ironsspellbooks.api.registry.SchoolRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import io.redspace.ironsspellbooks.api.spells.CastSource;
import io.redspace.ironsspellbooks.api.spells.CastType;
import io.redspace.ironsspellbooks.api.spells.SpellRarity;
import io.redspace.ironsspellbooks.api.util.Utils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

/**
 * A registered Iron's Spellbooks proxy spell that carries no effect of its own:
 * its {@link #onCast} reads the Ars spell payload from the casting book's
 * cross-cast sidecar component (matched by this proxy's pool id) and delegates
 * to {@link CrossCastingHandler#castArsSpell}, so the real Ars spell runs
 * through Ars 'n Spells' existing cross-cast cost / multiplier / scaling /
 * cooldown pipeline.
 *
 * <p><b>Cost is charged exactly once.</b> {@link #getManaCost} returns 0, so
 * Iron's deducts nothing for the proxy itself, and at {@code SpellOnCastEvent}
 * time there is no {@code CrossCastContext} yet (it is opened inside the
 * delegated cast), so {@code CrossCastIronsHandler} adds nothing either. The true
 * cost is taken by the delegated Ars cast via {@code onArsSpellCost}.
 *
 * <p><b>Iron's-gated.</b> Only loaded when {@code irons_spellbooks} is present
 * (constructed by {@link ArsCrossProxyRegistry}).
 */
public class ArsCrossProxySpell extends AbstractSpell {
    private static final Logger LOGGER = LoggerFactory.getLogger(ArsCrossProxySpell.class);
    private final int poolId;
    private final ResourceLocation spellResource;
    private final DefaultConfig defaultConfig;

    public ArsCrossProxySpell(int poolId) {
        this.poolId = poolId;
        this.spellResource = ArsCrossProxyRegistry.spellId(poolId);
        // No intrinsic cost/power: the delegated Ars cast owns all of that.
        this.baseManaCost = 0;
        this.manaCostPerLevel = 0;
        this.baseSpellPower = 1;
        this.spellPowerPerLevel = 0;
        this.castTime = 0;
        // ENDER school => requiresLearning == false, so a programmatically-added
        // proxy slot is never blocked by Iron's "not learned" cast gate.
        this.defaultConfig = new DefaultConfig()
            .setMinRarity(SpellRarity.COMMON)
            .setSchoolResource(SchoolRegistry.ENDER_RESOURCE)
            .setMaxLevel(1)
            .setCooldownSeconds(0.0)
            .build();
    }

    public int getPoolId() {
        return poolId;
    }

    @Override
    public ResourceLocation getSpellResource() {
        return spellResource;
    }

    @Override
    public DefaultConfig getDefaultConfig() {
        return defaultConfig;
    }

    @Override
    public CastType getCastType() {
        return CastType.INSTANT;
    }

    @Override
    public int getManaCost(int spellLevel) {
        // Real cost is charged by the delegated Ars cast (onArsSpellCost). The
        // proxy must be free to Iron's so the player is never double-charged.
        return 0;
    }

    @Override
    public void onCast(Level level, int spellLevel, LivingEntity entity, CastSource castSource,
                       MagicData playerMagicData) {
        if (level.isClientSide() || !(entity instanceof ServerPlayer player)) {
            return;
        }
        ItemStack recordedCastingItem = playerMagicData.getPlayerCastingItem();
        ItemStack book = resolveCastingBook(player, recordedCastingItem);
        if (book.isEmpty()) {
            logDebug("Proxy {} could not find a bound spellbook (recorded={}, main={}, off={}, equipped={})",
                poolId, describe(recordedCastingItem), describe(player.getMainHandItem()),
                describe(player.getOffhandItem()), describe(Utils.getPlayerSpellbookStack(player)));
            return;
        }
        Optional<CrossModSpell> entry = CrossModSpellComponents.findEntryByProxyPoolId(book, poolId);
        if (entry.isEmpty() || entry.get().arsSpellTag().isEmpty()) {
            logDebug("Proxy {} resolved {} but its Ars payload is missing", poolId, describe(book));
            return;
        }
        if (book != recordedCastingItem) {
            logDebug("Proxy {} recovered bound spellbook from player hand: {}", poolId, describe(book));
        }
        CrossCastingHandler.castArsSpell(player, book, entry.get());
    }

    /**
     * Iron's 3.16.2 may expose a transient casting-stack copy that does not carry
     * third-party data components. Prefer it when complete, then recover only
     * from the hands that can actually be responsible for the current cast.
     */
    private ItemStack resolveCastingBook(ServerPlayer player, ItemStack recordedCastingItem) {
        if (hasProxyPayload(recordedCastingItem)) {
            return recordedCastingItem;
        }
        ItemStack mainHand = player.getMainHandItem();
        if (hasProxyPayload(mainHand)) {
            return mainHand;
        }
        ItemStack offHand = player.getOffhandItem();
        if (hasProxyPayload(offHand)) {
            return offHand;
        }
        ItemStack equippedSpellbook = Utils.getPlayerSpellbookStack(player);
        if (hasProxyPayload(equippedSpellbook)) {
            return equippedSpellbook;
        }
        return ItemStack.EMPTY;
    }

    private boolean hasProxyPayload(ItemStack stack) {
        return stack != null && !stack.isEmpty()
            && CrossModSpellComponents.findEntryByProxyPoolId(stack, poolId)
                .filter(entry -> entry.arsSpellTag().isPresent())
                .isPresent();
    }

    private static String describe(ItemStack stack) {
        return stack == null ? "null" : stack.getItem() + " x" + stack.getCount()
            + " crossSpells=" + CrossModSpellComponents.has(stack);
    }

    private static void logDebug(String message, Object... args) {
        if (AnsConfig.DEBUG_MODE != null && AnsConfig.DEBUG_MODE.get()) {
            LOGGER.info("[NativeArsProxy] " + message, args);
        }
    }
}
